import{o as S,c as V,a as ke,b as d,d as se,m as Ae,r as F,u as Oe,e as be,f as Be,t as K,n as _e,g as De,F as Se,h as je,i as Ne,w as te,j as T,k as I,l as Re,R as He,p as Ue,q as ye,s as qe,_ as Ge,v as Ke,x as We,y as Qe}from"./vendor-77386604.js";import"./__commonjsHelpers__-de833af9.js";(function(){const r=document.createElement("link").relList;if(r&&r.supports&&r.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))o(t);new MutationObserver(t=>{for(const c of t)if(c.type==="childList")for(const f of c.addedNodes)f.tagName==="LINK"&&f.rel==="modulepreload"&&o(f)}).observe(document,{childList:!0,subtree:!0});function n(t){const c={};return t.integrity&&(c.integrity=t.integrity),t.referrerPolicy&&(c.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?c.credentials="include":t.crossOrigin==="anonymous"?c.credentials="omit":c.credentials="same-origin",c}function o(t){if(t.ep)return;t.ep=!0;const c=n(t);fetch(t.href,c)}})();const Je="/hero.jpg",E=(e,r)=>{const n=e.__vccOpts||e;for(const[o,t]of r)n[o]=t;return n},Xe={},Ye={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24"};function Ze(e,r){return S(),V("svg",Ye,r[0]||(r[0]=[ke('<path fill="currentColor" d="M12,18c-3.3,0-6-2.7-6-6s2.7-6,6-6s6,2.7,6,6S15.3,18,12,18zM12,8c-2.2,0-4,1.8-4,4c0,2.2,1.8,4,4,4c2.2,0,4-1.8,4-4C16,9.8,14.2,8,12,8z"></path><path fill="currentColor" d="M12,4c-0.6,0-1-0.4-1-1V1c0-0.6,0.4-1,1-1s1,0.4,1,1v2C13,3.6,12.6,4,12,4z"></path><path fill="currentColor" d="M12,24c-0.6,0-1-0.4-1-1v-2c0-0.6,0.4-1,1-1s1,0.4,1,1v2C13,23.6,12.6,24,12,24z"></path><path fill="currentColor" d="M5.6,6.6c-0.3,0-0.5-0.1-0.7-0.3L3.5,4.9c-0.4-0.4-0.4-1,0-1.4s1-0.4,1.4,0l1.4,1.4c0.4,0.4,0.4,1,0,1.4C6.2,6.5,5.9,6.6,5.6,6.6z"></path><path fill="currentColor" d="M19.8,20.8c-0.3,0-0.5-0.1-0.7-0.3l-1.4-1.4c-0.4-0.4-0.4-1,0-1.4s1-0.4,1.4,0l1.4,1.4c0.4,0.4,0.4,1,0,1.4C20.3,20.7,20,20.8,19.8,20.8z"></path><path fill="currentColor" d="M3,13H1c-0.6,0-1-0.4-1-1s0.4-1,1-1h2c0.6,0,1,0.4,1,1S3.6,13,3,13z"></path><path fill="currentColor" d="M23,13h-2c-0.6,0-1-0.4-1-1s0.4-1,1-1h2c0.6,0,1,0.4,1,1S23.6,13,23,13z"></path><path fill="currentColor" d="M4.2,20.8c-0.3,0-0.5-0.1-0.7-0.3c-0.4-0.4-0.4-1,0-1.4l1.4-1.4c0.4-0.4,1-0.4,1.4,0s0.4,1,0,1.4l-1.4,1.4C4.7,20.7,4.5,20.8,4.2,20.8z"></path><path fill="currentColor" d="M18.4,6.6c-0.3,0-0.5-0.1-0.7-0.3c-0.4-0.4-0.4-1,0-1.4l1.4-1.4c0.4-0.4,1-0.4,1.4,0s0.4,1,0,1.4l-1.4,1.4C18.9,6.5,18.6,6.6,18.4,6.6z"></path>',9)]))}const er=E(Xe,[["render",Ze],["__file","Sun.vue"]]),rr={},nr={xmlns:"http://www.w3.org/2000/svg",viewBox:"0 0 24 24"};function tr(e,r){return S(),V("svg",nr,r[0]||(r[0]=[d("path",{fill:"currentColor",d:"M12.1,22c-0.3,0-0.6,0-0.9,0c-5.5-0.5-9.5-5.4-9-10.9c0.4-4.8,4.2-8.6,9-9c0.4,0,0.8,0.2,1,0.5c0.2,0.3,0.2,0.8-0.1,1.1c-2,2.7-1.4,6.4,1.3,8.4c2.1,1.6,5,1.6,7.1,0c0.3-0.2,0.7-0.3,1.1-0.1c0.3,0.2,0.5,0.6,0.5,1c-0.2,2.7-1.5,5.1-3.6,6.8C16.6,21.2,14.4,22,12.1,22zM9.3,4.4c-2.9,1-5,3.6-5.2,6.8c-0.4,4.4,2.8,8.3,7.2,8.7c2.1,0.2,4.2-0.4,5.8-1.8c1.1-0.9,1.9-2.1,2.4-3.4c-2.5,0.9-5.3,0.5-7.5-1.1C9.2,11.4,8.1,7.7,9.3,4.4z"},null,-1)]))}const or=E(rr,[["render",tr],["__file","Moon.vue"]]),lr={},sr={width:"1.4em",height:"1.4em",viewBox:"0 0 24 24"};function ar(e,r){return S(),V("svg",sr,r[0]||(r[0]=[ke('<g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><path d="M8.59 13.51l6.83 3.98"></path><path d="M15.41 6.51l-6.82 3.98"></path></g>',1)]))}const ir=E(lr,[["render",ar],["__file","Share.vue"]]),cr={},ur={width:"1.7em",height:"1.7em",viewBox:"0 0 24 24",fill:"currentColor"};function pr(e,r){return S(),V("svg",ur,r[0]||(r[0]=[d("path",{d:"M10.9,2.1c-4.6,0.5-8.3,4.2-8.8,8.7c-0.5,4.7,2.2,8.9,6.3,10.5C8.7,21.4,9,21.2,9,20.8v-1.6c0,0-0.4,0.1-0.9,0.1 c-1.4,0-2-1.2-2.1-1.9c-0.1-0.4-0.3-0.7-0.6-1C5.1,16.3,5,16.3,5,16.2C5,16,5.3,16,5.4,16c0.6,0,1.1,0.7,1.3,1c0.5,0.8,1.1,1,1.4,1 c0.4,0,0.7-0.1,0.9-0.2c0.1-0.7,0.4-1.4,1-1.8c-2.3-0.5-4-1.8-4-4c0-1.1,0.5-2.2,1.2-3C7.1,8.8,7,8.3,7,7.6C7,7.2,7,6.6,7.3,6 c0,0,1.4,0,2.8,1.3C10.6,7.1,11.3,7,12,7s1.4,0.1,2,0.3C15.3,6,16.8,6,16.8,6C17,6.6,17,7.2,17,7.6c0,0.8-0.1,1.2-0.2,1.4 c0.7,0.8,1.2,1.8,1.2,3c0,2.2-1.7,3.5-4,4c0.6,0.5,1,1.4,1,2.3v2.6c0,0.3,0.3,0.6,0.7,0.5c3.7-1.5,6.3-5.1,6.3-9.3 C22,6.1,16.9,1.4,10.9,2.1z"},null,-1)]))}const fr=E(cr,[["render",pr],["__file","GitHub.vue"]]),vr={class:"number"},dr={key:0},mr=["onClick"],gr=se({__name:"VersionSelect",props:Ae({pkg:{},label:{}},{modelValue:{},modelModifiers:{}}),emits:["update:modelValue"],setup(e){const r=F(!1),n=F(),o=Oe(e,"modelValue"),t=e;async function c(){r.value=!r.value,n.value||(n.value=await f())}async function f(){const v=await fetch(`https://data.jsdelivr.com/v1/package/npm/${t.pkg}`),{versions:a}=await v.json();if(t.pkg==="vue"){let l=a[0].includes("-");const i=[];for(const u of a)if(u.includes("-")?l&&i.push(u):(i.push(u),l=!1),i.length>=30||u==="3.0.10")break;return i}else{if(t.pkg==="typescript")return a.filter(l=>!l.includes("dev")&&!l.includes("insiders"));if(t.pkg==="t-ui-plus")return a.filter(l=>!l.includes("alpha"))}return a}function s(v){o.value=v,r.value=!1}return be(()=>{window.addEventListener("click",()=>{r.value=!1}),window.addEventListener("blur",()=>{var v;((v=document.activeElement)==null?void 0:v.tagName)==="IFRAME"&&(r.value=!1)})}),(v,a)=>(S(),V("div",{class:"version",onClick:a[1]||(a[1]=te(()=>{},["stop"]))},[d("span",{class:_e(["active-version",t.pkg]),onClick:c},[Be(K(v.label)+" ",1),d("span",vr,K(o.value),1)],2),d("ul",{class:_e(["versions",{expanded:r.value}])},[n.value?De("",!0):(S(),V("li",dr,a[2]||(a[2]=[d("a",null,"loading versions...",-1)]))),(S(!0),V(Se,null,je(n.value,l=>(S(),V("li",{key:l},[d("a",{onClick:i=>s(l)},"v"+K(l),9,mr)]))),128)),d("div",{onClick:a[0]||(a[0]=l=>r.value=!1)},[Ne(v.$slots,"default")])],2)]))}});const Z=E(gr,[["__file","VersionSelect.vue"]]),hr={class:"links"},_r={href:"https://github.com/wocwin/wocwin-playground",target:"_blank",title:"View on GitHub",class:"github"},ee="latest",yr=se({__name:"Header",props:{store:{},dev:{type:Boolean},ssr:{type:Boolean}},emits:["toggle-theme","toggle-ssr","toggle-dev","changePPCVersion"],setup(e,{emit:r}){const n=e,o=r,{store:t}=n,c=F(`@${ee}`),f=F("latest");function s(u){o("changePPCVersion",u),t.state.dependencyVersion={"t-ui-plus":u},f.value=u}async function v(u){c.value="loading...",await t.setVueVersion(u),c.value=`v${u}`}function a(){t.resetVueVersion(),c.value=`@${ee}`}async function l(u){if(u.metaKey){window.location.href="http://localhost:5173/"+window.location.hash;return}await navigator.clipboard.writeText(location.href),alert("Sharable URL has been copied to clipboard.")}function i(){const u=document.documentElement.classList;u.toggle("dark"),localStorage.setItem("vue-sfc-playground-prefer-dark",String(u.contains("dark"))),o("toggle-theme",u.contains("dark"))}return(u,h)=>(S(),V("nav",null,[h[2]||(h[2]=d("h1",null,[d("img",{alt:"logo",src:Je}),d("span",null,"TuiPlus SFC Playground")],-1)),d("div",hr,[T(Z,{"model-value":f.value,pkg:"t-ui-plus",label:"TuiPlus Version","onUpdate:modelValue":s},null,8,["model-value"]),T(Z,{modelValue:I(t).state.typescriptVersion,"onUpdate:modelValue":h[0]||(h[0]=P=>I(t).state.typescriptVersion=P),pkg:"typescript",label:"TypeScript Version"},null,8,["modelValue"]),T(Z,{"model-value":c.value,pkg:"vue",label:"Vue Version","onUpdate:modelValue":v},{default:Re(()=>[d("li",null,[d("a",{onClick:a},"This Commit ("+K(ee)+")")]),h[1]||(h[1]=d("li",null,[d("a",{href:"https://app.netlify.com/sites/vue-sfc-playground/deploys",target:"_blank"},"Commits History")],-1))]),_:1,__:[1]},8,["model-value"]),d("button",{title:"Toggle dark mode",class:"toggle-dark",onClick:i},[T(er,{class:"light"}),T(or,{class:"dark"})]),d("button",{title:"Copy sharable URL",class:"share",onClick:l},[T(ir)]),d("a",_r,[T(fr)])])]))}});const wr=E(yr,[["__file","Header.vue"]]),Cr=`<script setup>\r
import App from './App.vue'\r
import { setupTuiPlus } from './t-ui-plus.js'\r
setupTuiPlus()\r
<\/script>\r
\r
<template>\r
  <App />\r
</template>\r
`,kr=`<template>\r
  <TLayoutPage>\r
    <TLayoutPageItem>\r
      <TForm ref="TFormDemo" v-model="formOpts.ref" :formOpts="formOpts" />\r
    </TLayoutPageItem>\r
  </TLayoutPage>\r
</template>\r
\r
<script setup lang="ts">\r
import { ref, reactive } from 'vue'\r
import { TLayoutPage, TLayoutPageItem, TForm } from 't-ui-plus'\r
// 获取ref\r
const TFormDemo: any = ref<HTMLElement | null>(null)\r
// 提交formOpts.ref 方式form表单\r
const submitForm = () => {\r
  if (formOpts.ref) {\r
    formOpts.ref.validate(valid => {\r
      console.log(88, valid)\r
      console.log(77, formOpts.formData)\r
      if (!valid) return\r
      console.log('最终数据', formOpts.formData)\r
    })\r
  }\r
}\r
\r
// 重置form表单\r
const resetForm = () => {\r
  TFormDemo.value.resetFields()\r
}\r
const accountFocus = ({ type }: { type: string }, row: any) => {\r
  console.log('账号聚焦事件', type, row)\r
}\r
const accountClear = () => {\r
  console.log('账号清空事件')\r
}\r
const accountBlur = ({ type }: { type: string }) => {\r
  console.log('账号失焦事件', type)\r
}\r
interface NameBlurEvent {\r
  type: string\r
}\r
\r
const nameBlur = ({ type }: NameBlurEvent) => {\r
  console.log('昵称失焦事件', type)\r
}\r
interface FormInstance {\r
  validate: (callback: (valid: boolean) => void) => void\r
  resetFields?: () => void\r
}\r
\r
const formOpts = reactive({\r
  ref: null as null | FormInstance,\r
  formData: {\r
    account: 'wocwin', // *用户账号\r
    password: null, // *用户密码\r
    name: null, // *用户昵称\r
    qq: null, // qq\r
    email: null, // 邮箱\r
    desc: null // 描述\r
  },\r
  fieldList: [\r
    {\r
      label: '账号',\r
      value: 'account',\r
      type: 'input',\r
      comp: 'el-input',\r
      eventHandle: {\r
        focus: (val: { type: string }, row: any) => accountFocus(val, row),\r
        clear: () => accountClear(),\r
        blur: (val: { type: string }) => accountBlur(val)\r
      }\r
    },\r
    { label: '密码', value: 'password', type: 'password', comp: 'el-input' },\r
    {\r
      label: '昵称',\r
      value: 'name',\r
      type: 'input',\r
      comp: 'el-input',\r
      eventHandle: {\r
        blur: (val: NameBlurEvent) => nameBlur(val)\r
      }\r
    },\r
\r
    { label: 'QQ', value: 'qq', type: 'input', comp: 'el-input' },\r
    { label: '邮箱', value: 'email', type: 'input', comp: 'el-input' },\r
    {\r
      label: '描述',\r
      value: 'desc',\r
      type: 'textarea',\r
      comp: 'el-input',\r
      widthSize: 1\r
    }\r
  ],\r
  operatorList: [\r
    { label: '提交', bind: { type: 'danger' }, fun: submitForm },\r
    { label: '重置', bind: { type: 'primary' }, fun: resetForm }\r
  ]\r
})\r
<\/script>\r
`,we=`import { getCurrentInstance } from 'vue'\r
import TuiPlus from 't-ui-plus'\r
import ElementPlus from 'element-plus'\r
\r
const version = '2.7.8'\r
\r
const createLink = (resolve, reject, href) => {\r
  const link = document.createElement('link')\r
  link.rel = 'stylesheet'\r
  link.href = href\r
  link.addEventListener('load', resolve)\r
  link.addEventListener('error', reject)\r
  document.body.append(link)\r
}\r
\r
let installed = false\r
await loadStyle()\r
await loadEPStyle()\r
\r
export function setupTuiPlus() {\r
  if (installed) return\r
  const instance = getCurrentInstance()\r
  instance.appContext.app.use(TuiPlus)\r
  instance.appContext.app.use(ElementPlus)\r
  installed = true\r
}\r
\r
export function loadStyle() {\r
  return new Promise((resolve, reject) => {\r
    createLink(resolve, reject, 'https://unpkg.com/t-ui-plus/index.css')\r
  })\r
}\r
\r
export function loadEPStyle() {\r
  return new Promise((resolve, reject) => {\r
    createLink(resolve, reject, \`https://unpkg.com/element-plus@\${version}/dist/index.css\`)\r
  })\r
}\r
`;var g=Uint8Array,A=Uint16Array,br=Int32Array,Ve=new g([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),Pe=new g([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),Sr=new g([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),Te=function(e,r){for(var n=new A(31),o=0;o<31;++o)n[o]=r+=1<<e[o-1];for(var t=new br(n[30]),o=1;o<30;++o)for(var c=n[o];c<n[o+1];++c)t[c]=c-n[o]<<5|o;return{b:n,r:t}},xe=Te(Ve,2),Me=xe.b,Vr=xe.r;Me[28]=258,Vr[258]=28;var Pr=Te(Pe,0),Tr=Pr.b,oe=new A(32768);for(var p=0;p<32768;++p){var x=(p&43690)>>1|(p&21845)<<1;x=(x&52428)>>2|(x&13107)<<2,x=(x&61680)>>4|(x&3855)<<4,oe[p]=((x&65280)>>8|(x&255)<<8)>>1}var H=function(e,r,n){for(var o=e.length,t=0,c=new A(r);t<o;++t)e[t]&&++c[e[t]-1];var f=new A(r);for(t=1;t<r;++t)f[t]=f[t-1]+c[t-1]<<1;var s;if(n){s=new A(1<<r);var v=15-r;for(t=0;t<o;++t)if(e[t])for(var a=t<<4|e[t],l=r-e[t],i=f[e[t]-1]++<<l,u=i|(1<<l)-1;i<=u;++i)s[oe[i]>>v]=a}else for(s=new A(o),t=0;t<o;++t)e[t]&&(s[t]=oe[f[e[t]-1]++]>>15-e[t]);return s},U=new g(288);for(var p=0;p<144;++p)U[p]=8;for(var p=144;p<256;++p)U[p]=9;for(var p=256;p<280;++p)U[p]=7;for(var p=280;p<288;++p)U[p]=8;var Fe=new g(32);for(var p=0;p<32;++p)Fe[p]=5;var xr=H(U,9,1),Mr=H(Fe,5,1),re=function(e){for(var r=e[0],n=1;n<e.length;++n)e[n]>r&&(r=e[n]);return r},b=function(e,r,n){var o=r/8|0;return(e[o]|e[o+1]<<8)>>(r&7)&n},ne=function(e,r){var n=r/8|0;return(e[n]|e[n+1]<<8|e[n+2]<<16)>>(r&7)},Fr=function(e){return(e+7)/8|0},ae=function(e,r,n){(r==null||r<0)&&(r=0),(n==null||n>e.length)&&(n=e.length);var o=new g(n-r);return o.set(e.subarray(r,n)),o},Er=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],C=function(e,r,n){var o=new Error(r||Er[e]);if(o.code=e,Error.captureStackTrace&&Error.captureStackTrace(o,C),!n)throw o;return o},Lr=function(e,r,n,o){var t=e.length,c=o?o.length:0;if(!t||r.f&&!r.l)return n||new g(0);var f=!n||r.i!=2,s=r.i;n||(n=new g(t*3));var v=function(me){var ge=n.length;if(me>ge){var he=new g(Math.max(ge*2,me));he.set(n),n=he}},a=r.f||0,l=r.p||0,i=r.b||0,u=r.l,h=r.d,P=r.m,m=r.n,_=t*8;do{if(!u){a=b(e,l,1);var O=b(e,l+1,3);if(l+=3,O)if(O==1)u=xr,h=Mr,P=9,m=5;else if(O==2){var D=b(e,l,31)+257,ie=b(e,l+10,15)+4,ce=D+b(e,l+5,31)+1;l+=14;for(var j=new g(ce),W=new g(19),w=0;w<ie;++w)W[Sr[w]]=b(e,l+w*3,7);l+=ie*3;for(var ue=re(W),Ee=(1<<ue)-1,Le=H(W,ue,1),w=0;w<ce;){var pe=Le[b(e,l,Ee)];l+=pe&15;var y=pe>>4;if(y<16)j[w++]=y;else{var $=0,q=0;for(y==16?(q=3+b(e,l,3),l+=2,$=j[w-1]):y==17?(q=3+b(e,l,7),l+=3):y==18&&(q=11+b(e,l,127),l+=7);q--;)j[w++]=$}}var fe=j.subarray(0,D),k=j.subarray(D);P=re(fe),m=re(k),u=H(fe,P,1),h=H(k,m,1)}else C(1);else{var y=Fr(l)+4,L=e[y-4]|e[y-3]<<8,B=y+L;if(B>t){s&&C(0);break}f&&v(i+L),n.set(e.subarray(y,B),i),r.b=i+=L,r.p=l=B*8,r.f=a;continue}if(l>_){s&&C(0);break}}f&&v(i+131072);for(var $e=(1<<P)-1,ze=(1<<m)-1,Q=l;;Q=l){var $=u[ne(e,l)&$e],z=$>>4;if(l+=$&15,l>_){s&&C(0);break}if($||C(2),z<256)n[i++]=z;else if(z==256){Q=l,u=null;break}else{var ve=z-254;if(z>264){var w=z-257,N=Ve[w];ve=b(e,l,(1<<N)-1)+Me[w],l+=N}var J=h[ne(e,l)&ze],X=J>>4;J||C(3),l+=J&15;var k=Tr[X];if(X>3){var N=Pe[X];k+=ne(e,l)&(1<<N)-1,l+=N}if(l>_){s&&C(0);break}f&&v(i+131072);var Y=i+ve;if(i<k){var de=c-k,Ie=Math.min(k,Y);for(de+i<0&&C(3);i<Ie;++i)n[i]=o[de+i]}for(;i<Y;i+=4)n[i]=n[i-k],n[i+1]=n[i+1-k],n[i+2]=n[i+2-k],n[i+3]=n[i+3-k];i=Y}}r.l=u,r.p=Q,r.b=i,r.f=a,u&&(a=1,r.m=P,r.d=h,r.n=m)}while(!a);return i==n.length?n:ae(n,0,i)},$r=new g(0),zr=function(e,r){return((e[0]&15)!=8||e[0]>>4>7||(e[0]<<8|e[1])%31)&&C(6,"invalid zlib data"),(e[1]>>5&1)==+!r&&C(6,"invalid zlib data: "+(e[1]&32?"need":"unexpected")+" dictionary"),(e[1]>>3&4)+2};function Ir(e,r){return Lr(e.subarray(zr(e,r&&r.dictionary),-4),{i:2},r&&r.out,r&&r.dictionary)}var Ce=typeof TextEncoder<"u"&&new TextEncoder,le=typeof TextDecoder<"u"&&new TextDecoder,Ar=0;try{le.decode($r,{stream:!0}),Ar=1}catch{}var Or=function(e){for(var r="",n=0;;){var o=e[n++],t=(o>127)+(o>223)+(o>239);if(n+t>e.length)return{s:r,r:ae(e,n-1)};t?t==3?(o=((o&15)<<18|(e[n++]&63)<<12|(e[n++]&63)<<6|e[n++]&63)-65536,r+=String.fromCharCode(55296|o>>10,56320|o&1023)):t&1?r+=String.fromCharCode((o&31)<<6|e[n++]&63):r+=String.fromCharCode((o&15)<<12|(e[n++]&63)<<6|e[n++]&63):r+=String.fromCharCode(o)}};function Br(e,r){if(r){for(var n=new g(e.length),o=0;o<e.length;++o)n[o]=e.charCodeAt(o);return n}if(Ce)return Ce.encode(e);for(var t=e.length,c=new g(e.length+(e.length>>1)),f=0,s=function(l){c[f++]=l},o=0;o<t;++o){if(f+5>c.length){var v=new g(f+8+(t-o<<1));v.set(c),c=v}var a=e.charCodeAt(o);a<128||r?s(a):a<2048?(s(192|a>>6),s(128|a&63)):a>55295&&a<57344?(a=65536+(a&1047552)|e.charCodeAt(++o)&1023,s(240|a>>18),s(128|a>>12&63),s(128|a>>6&63),s(128|a&63)):(s(224|a>>12),s(128|a>>6&63),s(128|a&63))}return ae(c,0,f)}function Dr(e,r){if(r){for(var n="",o=0;o<e.length;o+=16384)n+=String.fromCharCode.apply(null,e.subarray(o,o+16384));return n}else{if(le)return le.decode(e);var t=Or(e),c=t.s,n=t.r;return n.length&&C(8),c}}function jr(e){const r=atob(e);if(r.startsWith("xÚ")){const n=Br(r,!0),o=Ir(n);return Dr(o)}return decodeURIComponent(escape(r))}const M="https://unpkg.com",G="src/PlaygroundMain.vue",Nr="src/App.vue",R="src/t-ui-plus.js",Rr="2.7.8",Hr=se({__name:"App",setup(e){const r=()=>{document.documentElement.style.setProperty("--vh",window.innerHeight+"px")};window.addEventListener("resize",r),r();const n=F(!1),o=F(!1);let t=location.hash.slice(1);t.startsWith("__DEV__")&&(t=t.slice(7),n.value=!0),t.startsWith("__SSR__")&&(t=t.slice(7),o.value=!0);const c=M+"/@vue/runtime-dom/dist/runtime-dom.esm-browser.js",f=M+"/@vue/server-renderer/dist/server-renderer.esm-browser.js",s=new He({serializedState:t,defaultVueRuntimeURL:c,defaultVueServerRendererURL:f});s.setImportMap({imports:{...s.getImportMap().imports,"element-plus":M+`/element-plus@${Rr}/dist/index.full.mjs`,"t-ui-plus":M+"/t-ui-plus/index.mjs","@element-plus/icons-vue":M+"/@element-plus/icons-vue/dist/index.js"}});let v=kr;if(location.hash.slice(1)){const m=jr(location.hash.slice(1));v=JSON.parse(m)["App.vue"]}s.setFiles({...s.getFiles(),[Nr]:v,[G]:Cr,[R]:we}).then(()=>{s.state.mainFile=G,s.state.files[G].hidden=!0,s.state.files[R].hidden=!0});const a={script:{inlineTemplate:!n.value,isProd:!n.value,reactivityTransform:!0,defineModel:!0},style:{isProd:!n.value},template:{isProd:!n.value}};Ue(()=>{const m=s.serialize().replace(/^#/,o.value?"#__SSR__":"#").replace(/^#/,n.value?"#__DEV__":"#");history.replaceState({},"",m)});function l(){const m=n.value=!n.value;a.script.inlineTemplate=a.script.isProd=a.template.isProd=a.style.isProd=!m,s.setFiles(s.getFiles())}function i(){o.value=!o.value,s.setFiles(s.getFiles())}const u=F("dark");function h(m){u.value=m?"dark":"light"}const P=(m="latest")=>{const _=M+`/t-ui-plus@${m}`,O=_+"/index.css",y=we.replace(M+"/t-ui-plus/index.css",O),L=new We(R,y,!1);s.state.files[R]=L,qe(s,L).then(D=>s.state.errors=D),s.setImportMap({imports:{...s.getImportMap().imports,"t-ui-plus":_+"/index.mjs"}}),s.state.files[G].hidden=!0,s.state.files[R].hidden=!0;const B=`${location.origin}${location.pathname}#${s.serialize()}`;history.replaceState({},"",B)};return be(()=>{const m=document.documentElement.classList;h(m.contains("dark"))}),(m,_)=>(S(),V(Se,null,[T(wr,{store:I(s),dev:n.value,ssr:o.value,onToggleTheme:h,onToggleDev:l,onToggleSsr:i,onChangePPCVersion:P},null,8,["store","dev","ssr"]),T(I(Ke),{theme:u.value,editor:I(Ge),ssr:o.value,store:I(s),"show-compile-output":!0,"auto-resize":!0,"sfc-options":a,"clear-console":!1,onKeydown:[_[0]||(_[0]=ye(te(()=>{},["ctrl","prevent"]),["s"])),_[1]||(_[1]=ye(te(()=>{},["meta","prevent"]),["s"]))]},null,8,["theme","editor","ssr","store"])],64))}});const Ur=E(Hr,[["__file","App.vue"]]);window.VUE_DEVTOOLS_CONFIG={defaultSelectedAppId:"repl"};Qe(Ur).mount("#app");
